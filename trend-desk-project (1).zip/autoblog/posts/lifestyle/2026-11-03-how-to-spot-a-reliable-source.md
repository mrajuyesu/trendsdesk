---
title: "How to Spot a Reliable Source in 60 Seconds"
description: "Four quick checks to tell a trustworthy article from a misleading one."
category: "lifestyle"
date: "2026-11-03"
tags: ["media literacy", "how-to"]
sources: []
score: 10
status: "published"
---
## Check who wrote it
Look for a named author or a clear organisation with a track record and a corrections policy.

## Look for the original source
Good articles link to documents, data or official statements. If the claim has no origin, be careful.

## Compare two outlets
If only one site reports a surprising claim, wait. Real news usually appears in several places.

## What to watch
Strong emotion plus no sources is the classic sign of a post meant to spread, not to inform.
