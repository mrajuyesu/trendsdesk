---
title: "How Box Office Numbers Really Work"
description: "Why a film's ticket sales are not the same as its profit."
category: "entertainment"
date: "2026-11-01"
tags: ["movies", "box office"]
sources: []
score: 10
status: "published"
---
## Gross is not profit
The box office gross is the total ticket money collected. Cinemas keep a share and the studio receives the rest, with the split varying by country and film.

## Costs sit outside the number
A film's stated budget often leaves out marketing, which can be very large. A movie can earn a lot and still lose money.

## Other income counts
Streaming deals, TV rights, home video and merchandise add revenue after cinemas.

## What to watch
When you see a record headline, check whether it is worldwide or domestic, and whether it is adjusted for inflation.
