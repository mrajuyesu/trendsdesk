---
title: "How to Spot a Phishing Message in 30 Seconds"
description: "Five warning signs that a message is trying to trick you, and what to do instead of clicking."
category: "technology"
date: "2026-11-02"
tags: ["security", "scams"]
sources: []
score: 10
status: "published"
---
## It creates panic
Phishing messages push you to act fast: "your account closes today" or "payment failed". Real companies rarely demand instant action through a link.

## The sender does not match
Check the full address or number, not just the display name. Look for small spelling changes in the website name.

## The link goes somewhere else
Press and hold a link, or hover on a computer, to preview the address before opening it. If it looks odd, leave it.

## What to do instead
Open the official app or type the website address yourself. Delete and report the message, and never share a one-time password with anyone, even someone claiming to be from your bank.
