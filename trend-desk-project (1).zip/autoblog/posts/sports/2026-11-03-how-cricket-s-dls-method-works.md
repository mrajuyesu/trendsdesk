---
title: "How Cricket's DLS Method Works"
description: "How rain-affected limited-overs matches get a fair revised target."
category: "sports"
date: "2026-11-03"
tags: ["cricket", "rules"]
sources: []
score: 10
status: "published"
---
## The problem
When rain cuts a match short, the team batting second cannot fairly chase the same target in fewer overs.

## Resources, not just overs
The Duckworth-Lewis-Stern method treats overs left and wickets in hand as batting resources. A team with many wickets in hand can attack more freely.

## How the target changes
The method works out how much of its resources each side had and scales the target to match.

## What to watch
Losing early wickets drains a team's resources quickly, which is why revised targets can look surprisingly high or low.
