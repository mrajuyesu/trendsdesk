---
title: "What Is VAR and How Does Football Use It?"
description: "A simple guide to the video assistant referee and what it can and cannot change."
category: "sports"
date: "2026-10-31"
tags: ["football", "rules"]
sources: []
score: 10
status: "published"
---
## What VAR is
The Video Assistant Referee is a team of officials who watch replays and help the referee on the pitch.

## What can be reviewed
Only four kinds of decisions: goals, penalty decisions, direct red cards and mistaken identity.

## Who decides
VAR advises, but the on-field referee makes the final call, sometimes after watching the replay at the pitchside monitor.

## What to watch
Reviews target clear and obvious errors, which is why some close calls are not overturned.
