---
title: "Inflation Explained in Plain English"
description: "What inflation is, why prices rise, and how it affects your savings and salary."
category: "business"
date: "2026-11-01"
tags: ["economy", "inflation"]
sources: []
score: 10
status: "published"
---
## What inflation means
Inflation is the general rise in prices over time. At 6% a year, something that cost 100 rupees last year costs about 106 now.

## Why it happens
Prices rise when demand outpaces supply, when costs such as fuel or wages go up, or when a weaker currency makes imports expensive.

## Who it affects
Savings lose buying power if they earn less than inflation. People on fixed incomes feel it most, while borrowers with fixed-rate loans can benefit.

## What to watch
Central banks respond by changing interest rates. Compare any return on your savings with the inflation rate to see your real gain.
