---
title: "How the Stock Market Works: A Beginner's Map"
description: "What shares are, why prices move, and the basic terms you will keep hearing."
category: "business"
date: "2026-10-29"
tags: ["investing", "markets"]
sources: []
score: 10
status: "published"
---
## What a share is
A share is a small piece of ownership in a company. If the company grows or pays dividends, shareholders may benefit.

## Why prices move
Prices change as buyers and sellers agree on new values. News about profits, interest rates and the wider economy shifts what investors will pay.

## Terms to know
An index, such as the Nifty 50 or S&P 500, tracks a group of companies to show how a market is doing. A mutual fund or ETF pools money to hold many shares at once.

## What to watch
Prices can fall as well as rise, so only invest money you will not need soon. This is general information, not investment advice.
