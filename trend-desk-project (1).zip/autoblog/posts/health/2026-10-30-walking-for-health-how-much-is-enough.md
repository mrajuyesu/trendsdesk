---
title: "Walking for Health: How Much Is Enough?"
description: "What global guidelines say about activity, and how to start small."
category: "health"
date: "2026-10-30"
tags: ["walking", "fitness"]
sources: [{"title": "WHO: Physical activity fact sheet", "url": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"}]
score: 10
status: "published"
---
## The guideline
The World Health Organization recommends that adults do at least 150 to 300 minutes of moderate-intensity activity a week. Brisk walking counts.

## Start small
Ten-minute walks after meals add up. Build up time first, then pace.

## Make it stick
Walk with a friend at a regular time, and track your steps if that motivates you.

## What to watch
If you have a medical condition, or feel chest pain or dizziness, check with a doctor before increasing activity.
