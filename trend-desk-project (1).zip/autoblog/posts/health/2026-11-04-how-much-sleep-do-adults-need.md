---
title: "How Much Sleep Do Adults Need?"
description: "What health organisations recommend and the signs you may not be getting enough."
category: "health"
date: "2026-11-04"
tags: ["sleep", "wellness"]
sources: [{"title": "CDC: Sleep", "url": "https://www.cdc.gov/sleep/"}]
score: 10
status: "published"
---
## The general guide
Health bodies such as the US CDC advise that most adults get at least seven hours of sleep a night. Needs vary a little between people.

## Signs of too little
Trouble concentrating, irritability and relying on caffeine to get through the day can point to short sleep.

## Habits that help
Keep regular sleep and wake times, dim lights and screens before bed, and keep the room cool and dark.

## What to watch
If you often cannot sleep, snore loudly or feel exhausted despite enough hours, talk to a doctor.
